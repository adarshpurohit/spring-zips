insert into todo(id, username, description,target_date, is_done)
values(1001, 'adarsh','to learn angular',sysdate(),false);
insert into todo(id, username, description,target_date, is_done)
values(1002, 'adarsh','to learn spring',sysdate(),false);
insert into todo(id, username, description,target_date, is_done)
values(1003, 'adarsh','to learn spring boot',sysdate(),false);
insert into todo(id, username, description,target_date, is_done)
values(1004, 'adarsh','to learn html',sysdate(),false);