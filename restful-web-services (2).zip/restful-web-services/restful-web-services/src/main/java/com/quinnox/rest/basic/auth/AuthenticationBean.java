package com.quinnox.rest.basic.auth;

public class AuthenticationBean {

	public String message = "";
	public AuthenticationBean(String message) {
		this.message = message;
	}
	
	@Override
	public String toString() {
		return "HelloWorld [message=" + message + "]";
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
