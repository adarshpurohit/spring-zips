package com.quinnox.rest.webservices.restfulwebservices.helloworld;

public class HelloWorld {

	public String message = "";
	public HelloWorld(String message) {
		this.message = message;
	}
	
	@Override
	public String toString() {
		return "HelloWorld [message=" + message + "]";
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
