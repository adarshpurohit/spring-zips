package com.quinnox.apimonitor.apimonitoringtool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiMonitoringToolApplicationTests {

	@Test
	void contextLoads() {
	}

}
