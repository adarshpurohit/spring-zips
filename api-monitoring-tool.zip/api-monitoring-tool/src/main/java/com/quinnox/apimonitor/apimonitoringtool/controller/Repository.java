package com.quinnox.apimonitor.apimonitoringtool.controller;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.quinnox.apimonitor.apimonitoringtool.tool.Dashboard;


public interface Repository extends JpaRepository<Dashboard,Long> {

	
	
}
