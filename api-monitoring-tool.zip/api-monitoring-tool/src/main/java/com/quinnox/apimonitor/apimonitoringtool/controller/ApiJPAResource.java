package com.quinnox.apimonitor.apimonitoringtool.controller;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.quinnox.apimonitor.apimonitoringtool.tool.Dashboard;
@CrossOrigin(origins="http://localhost:4200")

@RestController
public class ApiJPAResource {

	
	@Autowired
	
	private Repository apiRepository;
	
	@GetMapping("/jpa/api")
	public List<Dashboard> getAllApi()
	{
		return apiRepository.findAll();
		//return todoService.findAll();
	}
}
//	@GetMapping("/jpa/users/{username}/todos/{id}")
//		public Todo getTodo(@PathVariable String username, @PathVariable long id)
//	{
//		return apiRepository.findById(id).get();
//		//return todoService.findById(id);
//	}
//		
	

	
//	
//	@PostMapping("/jpa/api")
//	 public ResponseEntity<Void> createApi(@RequestBody Dashboard dashboard)
//		{
//			
//			Dashboard createdDashboardInstance = apiRepository.save(dashboard);
//			//URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(createdTodo.getId()).toUri();
//			
////			return ResponseEntity.created(uri).build();
//		}
//}
