package com.quinnox.apimonitor.apimonitoringtool.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import com.quinnox.apimonitor.apimonitoringtool.tool.Dashboard;

@Service
public class ApiHardcodedService {

	private static List<Dashboard> api = new ArrayList();

	private static long idCounter = 100;

	static {
		api.add(new Dashboard(23,23,23,.65));
		
		
	}

}
