
package com.quinnox.apimonitor.apimonitoringtool.tool;

public class Dashboard {

	
	private int apiMonitored;
	private int apiPassed;
	private int apiFailed;
	private double avgApdex;
	public int getApiMonitored() {
		return apiMonitored;
	}
	public void setApiMonitored(int apiMonitored) {
		this.apiMonitored = apiMonitored;
	}
	public int getApiPassed() {
		return apiPassed;
	}
	public void setApiPassed(int apiPassed) {
		this.apiPassed = apiPassed;
	}
	public int getApiFailed() {
		return apiFailed;
	}
	public void setApiFailed(int apiFailed) {
		this.apiFailed = apiFailed;
	}
	public double getAvgApdex() {
		return avgApdex;
	}
	
	public Dashboard(int apiMonitored, int apiPassed, int apiFailed, double avgApdex) {
		super();
		this.apiMonitored = apiMonitored;
		this.apiPassed = apiPassed;
		this.apiFailed = apiFailed;
		this.avgApdex = avgApdex;
	}
	public void setAvgApdex(double avgApdex) {
		this.avgApdex = avgApdex;
	}
	
}
