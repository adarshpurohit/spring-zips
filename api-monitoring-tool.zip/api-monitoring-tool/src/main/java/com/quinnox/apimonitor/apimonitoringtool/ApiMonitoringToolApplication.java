package com.quinnox.apimonitor.apimonitoringtool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiMonitoringToolApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiMonitoringToolApplication.class, args);
	}

}
