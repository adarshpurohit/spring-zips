# spring-mongodb
How to intigrate spring boot with mongodb
