package com.javatechie.spring.mongo.api.model;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString

@Document(collection = "ApiMonitor")
public class ApiMonitorModel {
	@Id
	private String id;
	
	private String apiName;
	private String apiUrl;
	private String email;
	private String reminder;
	
	
	public ApiMonitorModel(String apiName, String apiUrl, String email, String reminder) {
		super();
		this.apiName = apiName;
		this.apiUrl = apiUrl;
		this.email = email;
		this.reminder = reminder;
	}
	public ApiMonitorModel() {
		// TODO Auto-generated constructor stub
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getApiName() {
		return apiName;
	}
	public void setApiName(String apiName) {
		this.apiName = apiName;
	}
	public String getApiUrl() {
		return apiUrl;
	}
	public void setApiUrl(String apiUrl) {
		this.apiUrl = apiUrl;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getReminder() {
		return reminder;
	}
	public void setReminder(String reminder) {
		this.reminder = reminder;
	}
	
	
	
	
	
}
