package com.javatechie.spring.mongo.api.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.javatechie.spring.mongo.api.model.ApiMonitorModel;

public interface ApiMonitorRepository extends MongoRepository<ApiMonitorModel, String>{
	
}
